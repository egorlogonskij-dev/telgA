import SwiftUI

@main
struct TeleDemoApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

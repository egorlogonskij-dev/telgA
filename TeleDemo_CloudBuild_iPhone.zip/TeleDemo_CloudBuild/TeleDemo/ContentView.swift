import SwiftUI

private struct DemoChat: Identifiable {
    let id = UUID()
    let name: String
    let message: String
    let time: String
    let symbol: String
    let color: Color
    var unread: Int = 0
    var online = false
}

private struct DemoMessage: Identifiable {
    let id = UUID()
    let text: String
    let isOutgoing: Bool
    let time: String
}

struct ContentView: View {
    @State private var searchText = ""
    @State private var selectedChat: DemoChat?
    @State private var messages: [UUID: [DemoMessage]] = [:]

    private let chats: [DemoChat] = [
        DemoChat(name: "Избранное", message: "Заметки и сохранённые сообщения", time: "09:41", symbol: "bookmark.fill", color: .blue),
        DemoChat(name: "Алекс", message: "Привет! Как дела?", time: "09:38", symbol: "person.fill", color: .orange, unread: 2, online: true),
        DemoChat(name: "Друзья", message: "Максим: Отлично 😎", time: "09:25", symbol: "person.3.fill", color: .purple, unread: 4),
        DemoChat(name: "Мама", message: "Не забудь позвонить", time: "Вчера", symbol: "heart.fill", color: .pink),
        DemoChat(name: "Новости", message: "Сегодня хорошая погода", time: "Вчера", symbol: "paperplane.fill", color: .teal)
    ]

    private var filteredChats: [DemoChat] {
        searchText.isEmpty ? chats : chats.filter {
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.message.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    Image(systemName: "line.3.horizontal").font(.title3)
                    Spacer()
                    Text("TeleDemo").font(.system(size: 20, weight: .bold))
                    Spacer()
                    Image(systemName: "square.and.pencil").font(.title3)
                }
                .foregroundStyle(.white)
                .padding()
                .background(Color(red: 0.08, green: 0.52, blue: 0.95))

                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Поиск", text: $searchText)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                .padding(10)
                .background(Color(uiColor: .secondarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: 11))
                .padding(.horizontal, 14)
                .padding(.vertical, 10)

                List(filteredChats) { chat in
                    Button { selectedChat = chat } label: {
                        ChatRow(chat: chat)
                    }
                    .buttonStyle(.plain)
                    .listRowInsets(EdgeInsets(top: 8, leading: 14, bottom: 8, trailing: 14))
                }
                .listStyle(.plain)
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(item: $selectedChat) { chat in
                ChatDetailView(chat: chat, messages: Binding(
                    get: { messages[chat.id, default: [
                        DemoMessage(text: "Привет! Это демонстрационный чат.", isOutgoing: false, time: "09:30"),
                        DemoMessage(text: "Здесь можно отправлять сообщения внутри макета.", isOutgoing: true, time: "09:31")
                    ]] },
                    set: { messages[chat.id] = $0 }
                ))
            }
        }
        .tint(.blue)
    }
}

private struct ChatRow: View {
    let chat: DemoChat
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(chat.color.gradient)
                Image(systemName: chat.symbol).font(.system(size: 23, weight: .semibold)).foregroundStyle(.white)
            }
            .frame(width: 54, height: 54)
            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Text(chat.name).font(.system(size: 16, weight: .semibold)).foregroundStyle(.primary)
                    Spacer()
                    Text(chat.time).font(.system(size: 12)).foregroundStyle(chat.unread > 0 ? .blue : .secondary)
                }
                HStack(spacing: 6) {
                    if chat.online { Circle().fill(.green).frame(width: 6, height: 6) }
                    Text(chat.message).font(.system(size: 14)).foregroundStyle(.secondary).lineLimit(1)
                    Spacer(minLength: 0)
                    if chat.unread > 0 {
                        Text("\(chat.unread)").font(.system(size: 12, weight: .bold)).foregroundStyle(.white)
                            .padding(.horizontal, 7).padding(.vertical, 3).background(.blue).clipShape(Capsule())
                    }
                }
            }
        }
        .contentShape(Rectangle())
    }
}

private struct ChatDetailView: View {
    let chat: DemoChat
    @Binding var messages: [DemoMessage]
    @State private var draft = ""
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(spacing: 10) {
                            Text("Сегодня").font(.caption).foregroundStyle(.secondary)
                                .padding(.horizontal, 12).padding(.vertical, 6)
                                .background(.ultraThinMaterial).clipShape(Capsule()).padding(.top, 12)
                            ForEach(messages) { message in MessageBubble(message: message).id(message.id) }
                        }
                        .padding(.horizontal, 12).padding(.bottom, 12)
                    }
                    .background(Color(uiColor: .systemGroupedBackground))
                    .onChange(of: messages.count) { _, _ in
                        if let last = messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
                    }
                }
                HStack(alignment: .bottom, spacing: 10) {
                    Image(systemName: "paperclip").font(.title3).foregroundStyle(.blue).padding(.bottom, 10)
                    TextField("Сообщение", text: $draft, axis: .vertical).lineLimit(1...5)
                        .padding(.horizontal, 12).padding(.vertical, 9)
                        .background(Color(uiColor: .secondarySystemGroupedBackground)).clipShape(RoundedRectangle(cornerRadius: 18))
                    Button(action: sendMessage) {
                        Image(systemName: "arrow.up.circle.fill").font(.system(size: 31)).foregroundStyle(.blue)
                    }
                    .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                .padding(.horizontal, 12).padding(.vertical, 9).background(Color(uiColor: .systemBackground))
            }
            .navigationTitle(chat.name).navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Назад") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { Image(systemName: "phone").foregroundStyle(.blue) }
            }
        }
    }

    private func sendMessage() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        messages.append(DemoMessage(text: text, isOutgoing: true, time: formatter.string(from: Date())))
        draft = ""
    }
}

private struct MessageBubble: View {
    let message: DemoMessage
    var body: some View {
        HStack {
            if message.isOutgoing { Spacer(minLength: 45) }
            VStack(alignment: .trailing, spacing: 4) {
                Text(message.text).font(.system(size: 16)).frame(maxWidth: .infinity, alignment: .leading)
                HStack(spacing: 4) {
                    Text(message.time).font(.system(size: 10))
                    if message.isOutgoing { Image(systemName: "checkmark").font(.system(size: 10, weight: .semibold)) }
                }
                .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            .background(message.isOutgoing ? Color(red: 0.82, green: 0.94, blue: 0.79) : Color(uiColor: .secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            if !message.isOutgoing { Spacer(minLength: 45) }
        }
    }
}
